﻿

#region Name Space Libraries
/***************************************************************************************************
*This section declares the name space libraries we are using 
* **************************************************************************************************/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Reflection;
using System.Diagnostics;

#endregion

/***************************************************************************************************
 * 
 * TutorialDataGrid.cs --  class demonstrating build out of a Custom User Control
 * 
 * Author: Charles Vance
 * 
 * Usage: 
 * - used for accessing a data table in an MSSQL database
 * 
 * Revision History:
 * - Initial Creation and testing version 1.0 07/28/2018 
 * - Version 2.0 8/6/2018  Prototype version
 * **************************************************************************************************/
namespace TutorialDataGrid
{
    public partial class TutorialDataGrid : UserControl
    {

        #region Class variable declaration
        /***************************************************************************************************
        * Class variable declaration assignments and object instantiation
        * **************************************************************************************************/
        DB dsets = new DB();
        DataRow dr;
        DataSet ds = new DataSet();
        String _Server = "";
        String _Database = "";
        String _User = "";
        String _Password = "";
        String _Table = "Batches";
        Int16 _BatchID = 1;
        String _BatchName = "Batch1";
        String _EquipName = "Equip1";
        Boolean _EditMode = false;
        Boolean _getsqldata = false;
        int SelectedRow = 0;
        String _BatchStartTime;
        String _BatchEndTime;
        List<DataRow> rowsToDelete = new List<DataRow>();
        

        //Event handler for Batch ID
        public delegate void BatchIDChangedEventHandler(object sender, SQLGridIntEventArgs e);
        //Event handler for Batch Name
        public delegate void BatchNameChangedEventHandler(object sender, SQLGridStringsEventArgs e);
        //Event handler for Equip Name
        public delegate void EquipNameChangedEventHandler(object sender, SQLGridStringsEventArgs e);
        //Event handler for Batch Start Time
        public delegate void BatchStartTimeChangedEventHandler(object sender, SQLGridStringsEventArgs e);
        //Event handler for Batch End Time
        public delegate void BatchEndTimeChangedEventHandler(object sender, SQLGridStringsEventArgs e);
        #endregion

        #region User Control Initialize
        /***************************************************************************************************
        * This section is auto generated 
        * **************************************************************************************************/
        public TutorialDataGrid()
        {
            InitializeComponent();

        }

        #endregion

        #region User Control Properties and Events
        /***************************************************************************************************
        * User Control Properties and Events
        * **************************************************************************************************/
        //sqldgServer property
        //************************************************************************
        //make the property browsable from Archestra
        [Category("Tutorial")]
        [Description("SqlDataGrid Database Server Name")]
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
        public String sqldgServer
        {
            get { return _Server; }
            set { _Server = value; }
        }

        //sqldgDatabase property
        //************************************************************************
        //make the property browsable from Archestra
        [Category("Tutorial")]
        [Description("SqlDataGrid Database to connect")]
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
        public String sqldgDatabase
        {
            get { return _Database; }
            set { _Database = value; }
        }

        //sqldgUser property
        //************************************************************************
        //make the property browsable from Archestra
        [Category("Tutorial")]
        [Description("SqlDataGrid Database User")]
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
        public String sqldgUser
        {
            get { return _User; }
            set { _User = value; }
        }

        //sqldgPassword property
        //************************************************************************
        //make the property browsable from Archestra
        [Category("Tutorial")]
        [Description("SqlDataGrid Database Password")]
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
        public String sqldgPassword
        {
            get { return _Password; }
            set { _Password = value; }
        }

        //sqldgTable property
        //************************************************************************
        //make the property browsable from Archestra
        [Category("Tutorial")]
        [Description("SqlDataGrid Table to Get")]
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
        public String sqldgTable
        {
            get { return _Table; }
            set { _Table = value; }
        }

        //sqldgGetData property
        //************************************************************************
        //make the property browsable from Archestra
        [Category("Tutorial")]
        [Description("SqlDataGrid Get Data Trigger")]
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
        public Boolean sqldgGetData
        {
            get { return _getsqldata; }
            set
            {
                _getsqldata = value;
                //update data grid
                GetData();
            } 
        }

        //sqldgBatchID property
        //************************************************************************
        //make the property browsable from Archestra
        [Category("Tutorial")]
        [Description("SqlDataGrid BatchID")]
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
        public Int16 sqldgBatchID
        {
            get { return _BatchID; }
            set
            {
                _BatchID = value;
            }
        }

        //sqldgBatchID Event
        //************************************************************************
        //make the event browsable from Archestra
        [Browsable(true)]
        public event BatchIDChangedEventHandler BatchIDChangedEvent;
        //Method that raises the event
        protected virtual void OnBatchIDChangedEvent(SQLGridIntEventArgs e)
        {
            //Ensure the event is not null 
            BatchIDChangedEventHandler bidceh = this.BatchIDChangedEvent;
            if (bidceh != null)
                bidceh(this, e);
        }

        //sqldgBatchName Property
        //************************************************************************
        //make the property browsable from Archestra
        [Category("Tutorial")]
        [Description("SqlDataGrid BatchName")]
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
        public String sqldgBatchName
        {
            get { return _BatchName; }
            set
            {
                lstStatus.Items.Insert(0, "Value " + value);
                _BatchName = value;
            }
        }

        //sqldgBatchName Event
        //************************************************************************
        //make the event browsable from Archestra
        [Browsable(true)]
        public event BatchNameChangedEventHandler BatchNameChangedEvent;
        //Method that raises the event
        protected virtual void OnBatchNameChangedEvent(SQLGridStringsEventArgs e)
        {
            //Ensure the event is not null 
            BatchNameChangedEventHandler bnceh = this.BatchNameChangedEvent;
            if (bnceh != null)
                bnceh(this, e);
        }

        //sqldgEquipName Property
        //************************************************************************
        //make the property browsable from Archestra
        [Category("Tutorial")]
        [Description("SqlDataGrid EquipName")]
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
        public String sqldgEquipName
        {
            get { return _EquipName; }
            set {
                    lstStatus.Items.Insert(0, "Value " + value);
                    _EquipName = value;
                }
        }

        //sqldgEquipName Event
        //************************************************************************
        //make the event browsable from Archestra
        [Browsable(true)]
        public event EquipNameChangedEventHandler EquipNameChangedEvent;
        //Method that raises the event
        protected virtual void OnEquipNameChangedEvent(SQLGridStringsEventArgs e)
        {
            //Ensure the event is not null 
            EquipNameChangedEventHandler enceh = this.EquipNameChangedEvent;
            if (enceh != null)
                enceh(this, e);
        }

        //sqldgBatchStartTime Property
        //************************************************************************
        //make the property browsable from Archestra
        [Category("Tutorial")]
        [Description("SqlDataGrid BatchStartTime")]
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
        public String     sqldgBatchStartTime
        {
            get { return _BatchStartTime; }
            set { _BatchStartTime = value; }
        }

        //sqldgBatchStartTime Event
        //************************************************************************
        //make the event browsable from Archestra
        [Browsable(true)]
        public event BatchStartTimeChangedEventHandler BatchStartTimeChangedEvent;
        //Method that raises the event
        protected virtual void OnBatchStartTimeChangedEvent(SQLGridStringsEventArgs e)
        {
            //Ensure the event is not null 
            BatchStartTimeChangedEventHandler sbtceh = this.BatchStartTimeChangedEvent;
            if (sbtceh != null)
                sbtceh(this, e);
        }

        //sqldgBatchEndTime Property
        //************************************************************************
        //make the property browsable from Archestra
        [Category("Tutorial")]
        [Description("SqlDataGrid BatchEndTime")]
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
        public String sqldgBatchEndTime
        {
            get { return _BatchEndTime; }
            set { _BatchEndTime = value; }
        }

        //sqldgBatchEndTime Event
        //************************************************************************
        //make the event browsable from Archestra
        [Browsable(true)]
        public event BatchEndTimeChangedEventHandler BatchEndTimeChangedEvent;
        //Method that raises the event
        protected virtual void OnBatchEndTimeChangedEvent(SQLGridStringsEventArgs e)
        {
            //Ensure the event is not null 
            BatchEndTimeChangedEventHandler ebtceh = this.BatchEndTimeChangedEvent;
            if (ebtceh != null)
                ebtceh(this, e);
        }

        //sqldgEditMode Property
        //************************************************************************
        //make the property browsable from Archestra

        [Description("SqlDataGrid EditMode")]
        [Category("Tutorial")]
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
        public Boolean sqldgEditMode
        {
            get { return _EditMode; }
            set
            {
                _EditMode = value;
                editmode(_EditMode);
            }
        }
        #endregion

        #region User Control Load
        /***************************************************************************************************
        * this is the first block of code added after the custom properties it will display the current version of our DLL
        * the Load event executes when the DLL is first called it is similiar to the OnShow event in Archestra
        * **************************************************************************************************/
        private void TutorialDataGrid_Load(object sender, EventArgs e)
        {
            //Instantiate the Assembly object using the Assembly namespace this object will contain the DLL info
            Assembly assembly = Assembly.GetExecutingAssembly();
            //instantiate the FileVersion object we will pass the Assembly object and get back the verison info
            FileVersionInfo fvi = FileVersionInfo.GetVersionInfo(assembly.Location);
            //Declare a string to collect the version info
            string version = fvi.FileVersion;
            //write the version info to our label to display on our control
            lblVersion.Text = "Version " + version;


            //clear the edit mode
            editmode(false);
        }
        #endregion

        #region Update 
        /***************************************************************************************************
        * Update Row Button This button updates the internal dataset with info from the external properties
        * **************************************************************************************************/
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            lstStatus.Items.Insert(0, "Selected Row " + SelectedRow);
            //load the batch and equipment name data from the external property into our dataset
            ds.Tables[_Table].Rows[SelectedRow]["BatchName"] = _BatchName;
            ds.Tables[_Table].Rows[SelectedRow]["EquipName"] = _EquipName;

            //String[] saStart = _BatchStartTime.Split(':');

            //convert the date time picker to date time format
            DateTime dtime = DateTime.Parse(_BatchStartTime);
            TimeSpan st = new TimeSpan(dtime.Hour, dtime.Minute, dtime.Second);

            //load the date time data into the data set
            ds.Tables[_Table].Rows[SelectedRow]["StartTime"] = st;

            //convert the date time picker to date time format
            dtime = DateTime.Parse(_BatchEndTime);
            st = new TimeSpan(dtime.Hour, dtime.Minute, dtime.Second);

            //load the date time data into the data set
            ds.Tables[_Table].Rows[SelectedRow]["EndTime"] = st;

            //clear the edit mode
            editmode(false);
        }

        #endregion

        #region Add Row
        /***************************************************************************************************
        * Add Row Button This button adds a new row to the internal dataset 
        * **************************************************************************************************/
        private void btnAddRow_Click(object sender, EventArgs e)
        {
            dr = ds.Tables["Batches"].NewRow();

            var MaxID = dgvTable.Rows.Cast<DataGridViewRow>()
                        .Max(r => Convert.ToInt32(r.Cells["BatchID"].Value));

            dr["BatchID"] = MaxID + 1;
            lstStatus.Items.Insert(0, "Selected Row " + SelectedRow);
            dr["BatchName"] = _BatchName;
            dr["EquipName"] = _EquipName;
            DateTime dtime = Convert.ToDateTime(_BatchStartTime);
            TimeSpan st = new TimeSpan(dtime.Hour, dtime.Minute, dtime.Second);
            dr["StartTime"] = st;
            dtime = Convert.ToDateTime(_BatchEndTime);
            st = new TimeSpan(dtime.Hour, dtime.Minute, dtime.Second);
            dr["EndTime"] = st;

            ds.Tables["Batches"].Rows.Add(dr);


            //clear the edit mode
            editmode(false);

        }

        #endregion

        #region Delete Row
        /***************************************************************************************************
        * Delete Row Button This button deletes a row from the table in the database
        * **************************************************************************************************/
        private void btnDeleteRow_Click(object sender, EventArgs e)
        {
            try
            {
                lstStatus.Items.Insert(0,"Selected Row " + SelectedRow);

                //ignore command if this is the last row
                if (ds.Tables[_Table].Rows.Count > 1)
                {

                    DataRowCollection rowCollection = ds.Tables[_Table].Rows;
                    rowCollection[SelectedRow].Delete();


                    //DataRow dr = ds.Tables[_Table].Rows[SelectedRow];
                    //dr.Delete();

                    //ds.Tables[_Table].AcceptChanges();
                    //clear the edit mdoe
                    editmode(false);
                }
                else
                {
                    //if the command is ignored let the user know why
                    MessageBox.Show("Cannot Delete Last Row");

                    //clear the edit mdoe
                    editmode(false);
                }
            }
            catch(Exception ex)
            { lstStatus.Items.Insert(0, "delete error " + ex.Message); }
        }

        #endregion

        #region Commit
        /***************************************************************************************************
        * Add Row Button This button adds a new row to the internal dataset 
        * **************************************************************************************************/
        private void btnCommit_Click(object sender, EventArgs e)
        {
            lstStatus.Items.Insert(0, "Selected Row " + SelectedRow);
            //call the commit method to commit changes to the database
            
            dsets.CommitSQL(_Server, _Database, _User, _Password, _Table, ds);
            ds.AcceptChanges();
            //format the data view grid
            dgvTable.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            //ds.Tables[_Table].AcceptChanges();
            
            //clear the edit mdoe
            editmode(false);
        }

        #endregion

        #region Edit Mode
        /***************************************************************************************************
        * Edit Mode private method call pass a Bool value true or false  nothing is returned this method 
        * sets all button visiblity to state of passed parameter
        * **************************************************************************************************/
        private void editmode(Boolean state)
        {
            btnUpdate.Visible = state;
            btnAddRow.Visible = state;
            btnDeleteRow.Visible = state;
            btnCommit.Visible = state;
        }

        #endregion

        #region Trigger Events
        /***************************************************************************************************
        * Row Enter - As the Row in the data grid is selected this private method triggers the various
        * events to update the client using the user control with current grid values
        * **************************************************************************************************/
        private void dgvTable_RowEnter(object sender, DataGridViewCellEventArgs e)
        {

            try
            {
                //get the current selected row info
                int index = e.RowIndex;// get the Row Index
                SelectedRow = index;
                lstStatus.Items.Insert(0, "Selected Row from dgv " + SelectedRow);
                DataGridViewRow selectedRow = dgvTable.Rows[index];

                //trigger the Batch ID Event
                _BatchID = Convert.ToInt16(ds.Tables[_Table].Rows[SelectedRow]["BatchID"].ToString());
                SQLGridIntEventArgs iargs = new SQLGridIntEventArgs(_BatchID);
                //Raise the event
                OnBatchIDChangedEvent(iargs);

                //trigger the Batch Name Event
                _BatchName = ds.Tables[_Table].Rows[SelectedRow]["BatchName"].ToString();
                SQLGridStringsEventArgs sargs1 = new SQLGridStringsEventArgs(_BatchName);
                //Raise the event
                OnBatchNameChangedEvent(sargs1);

                //trigger the Equipment Name Event
                _EquipName = ds.Tables[_Table].Rows[SelectedRow]["EquipName"].ToString();
                SQLGridStringsEventArgs sargs2 = new SQLGridStringsEventArgs(_EquipName);
                //Raise the event
                OnEquipNameChangedEvent(sargs2);

                //trigger the Batch Start Time Event
                _BatchStartTime = ds.Tables[_Table].Rows[SelectedRow]["StartTime"].ToString();
                SQLGridStringsEventArgs stargs = new SQLGridStringsEventArgs(_BatchStartTime);
                //Raise the event
                OnBatchStartTimeChangedEvent(stargs);

                //trigger the Batch End Time Event
                _BatchEndTime = ds.Tables[_Table].Rows[SelectedRow]["EndTime"].ToString();
                SQLGridStringsEventArgs etargs = new SQLGridStringsEventArgs(_BatchEndTime);
                //Raise the event
                OnBatchEndTimeChangedEvent(etargs);

            }
            catch(Exception ex)
            {
                //report errors via the status listbox
                lstStatus.Items.Insert(0, "Row Entry " + ex.Message);
            }
        }
        #endregion
         
        #region Get Data
        //private method to update the data grid when commanded
        private void GetData()
        {
            try
            {
                //clear the dataset
                ds.Clear();
                //load the dataset from the database
                ds = dsets.GetSQLdata(_Server, _Database, _User, _Password, _Table, ds);
                //write a message to the status list box
                lstStatus.Items.Insert(0, "ds.tables Row Count" + ds.Tables["Batches"].Rows.Count);
                //assign the dataset to the data view grid
                dgvTable.DataSource = ds;
                //name the dataset table 
                dgvTable.DataMember = _Table;
                //set the display propertoes for the datagrid
                dgvTable.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                //load the batch ID
                _BatchID = Convert.ToInt16(ds.Tables[_Table].Rows[0]["BatchID"].ToString());
                //clear the list box
                lstStatus.Items.Clear();
                //write info to list box
                lstStatus.Items.Insert(0, "Server: " + _Server + " Database: " + _Database + "User: " + _User + "Password: " + _Password + " Table: " + _Table);

            }
            catch (Exception ex)
            {
                //on error write error message to list box
                lstStatus.Items.Clear();
                lstStatus.Items.Insert(0, ex.Message);
            }

        }

        #endregion
    }

    #region Event Handlers
    /***************************************************************************************************
    * Event Argument Classes for handling event triggers
    * **************************************************************************************************/

    //Event Handler Class for handling integer events
    public class SQLGridIntEventArgs : EventArgs
    {
        private Int16 item;

        public SQLGridIntEventArgs(Int16 _item)
        {
            this.item = _item;
        }

        public Int16 _item
        {
            get { return this.item; }
        }
    }

    //Event Handler Class for handling string events
    public class SQLGridStringsEventArgs : EventArgs
    {
        private String item;

        public SQLGridStringsEventArgs(String _item)
        {
            this.item = _item;
        }

        public String _item
        {
            get { return this.item; }
        }
    }

    #endregion
}
