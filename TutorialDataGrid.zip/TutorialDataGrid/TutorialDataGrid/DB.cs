﻿// name space declarations
using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Windows;
using System.Drawing;
using System.Threading;
using System.Xml;
using System.Xml.Serialization;
using System.Diagnostics;
using System.Data.OleDb;
using System.Text.RegularExpressions;

/***************************************************************************************************
 * 
 * DB.cs --  class containing SQL functions
 * 
 * Author: Charles Vance
 * 
 * Usage: 
 * - used for connecting to a database and manipulating tables
 * 
 * Revision History:
 * - Initial Creation and testing version 1.0 07/28/2018
 * **************************************************************************************************/
namespace TutorialDataGrid
{
    public class DB
    {
        //Method that creates a connmection to the SQL database we pass in the server name, database name, user name and passowrd and a SQL connection object
        //the method builds a connection string and returns a connected SQL object 
        private SqlConnection GetSqlConnection(String Server, String Database, String User, String Password, SqlConnection conn)
        {
            //Build the connection string using parameters passed in
            conn.ConnectionString =
          "Server=" + Server + ";Database=" + Database + ";User Id=" + User + ";Password = " + Password + "; ";

            //return the connected object
            return conn;

        }

        //Method that uses the connection obejct to connect and retrieve MSSQL version info
        public String SQLgetVers(String Server, String Database, String User, String Password)
        {
            //declare a new string variable for returning the version info
            String retval = "";
            //instantiate a new connection object
            SqlConnection conn = new SqlConnection();
            //call the GetSqlConnection method to recieve a connected object
            conn = GetSqlConnection(Server, Database, User, Password, conn);

            //establish a try catch block to handle any errors
            try
            {
                //open the SQL connection
                conn.Open();
                //instantiate a SQL command object
                SqlCommand cmd = conn.CreateCommand();
                //Declare a new command type as text
                cmd.CommandType = CommandType.Text;
                //pass the command test to retrieve version info
                cmd.CommandText = "SELECT @@Version";
                //Convert the returned data into a string
                retval = (String)cmd.ExecuteScalar();
                //appned the connect sucecss message to end of return string
                retval += " Connect Success";
                //get rid of the command object
                cmd.Dispose();
            }
            catch (Exception ex)
            {
                //if there is a error return the error message
                retval = ex.Message;
            }
            finally
            {
                //always close the connection to teh database
                conn.Close();
            }
            //return the string containing either an error message or the NMSSQL version
            return retval;
        }
         
        //Method to retrieve MSSQl Table data pass in the connection info, the table name  and a clean dataset object
        public DataSet GetSQLdata(String Server, String Database, String User, String Password, String Table, DataSet ds)
        {
            //instantiate a new connection object
            SqlConnection conn = new SqlConnection();

            //dckare a string variable with the SQL command to use
            string sql = "SELECT * FROM Batches";
            //call the sql connection method to get a connected object
            conn = GetSqlConnection(Server, Database, User, Password, conn);
            //instantiate a new sql data adapter object using the sql command string and the connected sql object
            SqlDataAdapter dataadapter = new SqlDataAdapter(sql, conn);

            //open the connection to the database
            conn.Open();
            //use the dataadapter object fill method to batches table data into the dataset
            dataadapter.Fill(ds, Table);
            //close the connection
            conn.Close();

            //return the dataset with the Batches table data loaded
            return ds;
        }

        //Method to Delete a Row form a data table pass in the connection string info, the table name and the primary key of the row to delete
        public void DelSQLRow(String Server, String Database, String User, String Password, String Table, String BatchID)
        {
            //instantiate a new connection object
            SqlConnection conn = new SqlConnection();
            //call the sql connection method using the connection string info
            conn = GetSqlConnection(Server, Database, User, Password, conn);
            //open the connection
            conn.Open();
            //setup and execute the delete command
            using (SqlCommand cmd =
            new SqlCommand("DELETE FROM " + Table + " " +
                "WHERE BatchID=@Id", conn))
            {
                cmd.Parameters.AddWithValue("@Id", BatchID);

                int rows = cmd.ExecuteNonQuery();

            }
            //close the connection
            conn.Close();
        }

        //Method to commit changes to the database pass in the connection string, table name and dataset with table data to commit
        public void CommitSQL(String Server, String Database, String User, String Password, String Table, DataSet ds)
        {
            //instantiate new connection object
            SqlConnection conn = new SqlConnection();
            //retrieve connected object using the connection string info
            conn = GetSqlConnection(Server, Database, User, Password, conn);
            //open the connecton
            conn.Open();
            //instantiate new sql adapter object using table and connection object
            SqlDataAdapter daBatches = new SqlDataAdapter("Select * From " + Table, conn);
            SqlCommandBuilder objCommandBuilder = new SqlCommandBuilder(daBatches);
            //execute the data adapter update method for the selected table
            daBatches.Update(ds, Table);
            //close the connection
            conn.Close();
        }


    }
}
