﻿namespace testTutorialDataGrid
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnEdit = new System.Windows.Forms.Button();
            this.dtStart = new System.Windows.Forms.DateTimePicker();
            this.dtEnd = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtBatchName = new System.Windows.Forms.TextBox();
            this.txtEquipName = new System.Windows.Forms.TextBox();
            this.txtBatchID = new System.Windows.Forms.TextBox();
            this.tutorialDataGrid1 = new TutorialDataGrid.TutorialDataGrid();
            this.SuspendLayout();
            // 
            // btnEdit
            // 
            this.btnEdit.Location = new System.Drawing.Point(22, 51);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(127, 48);
            this.btnEdit.TabIndex = 1;
            this.btnEdit.Text = "Edit";
            this.btnEdit.UseVisualStyleBackColor = true;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // dtStart
            // 
            this.dtStart.CustomFormat = "HH:mm:ss";
            this.dtStart.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtStart.Location = new System.Drawing.Point(22, 261);
            this.dtStart.Name = "dtStart";
            this.dtStart.ShowUpDown = true;
            this.dtStart.Size = new System.Drawing.Size(126, 20);
            this.dtStart.TabIndex = 2;
            // 
            // dtEnd
            // 
            this.dtEnd.CustomFormat = "HH:mm:ss";
            this.dtEnd.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtEnd.Location = new System.Drawing.Point(22, 306);
            this.dtEnd.Name = "dtEnd";
            this.dtEnd.ShowUpDown = true;
            this.dtEnd.Size = new System.Drawing.Size(126, 20);
            this.dtEnd.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(61, 106);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Batch ID";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(52, 152);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Batch Name";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(41, 197);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(88, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "Equipment Name";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(42, 242);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(86, 13);
            this.label4.TabIndex = 9;
            this.label4.Text = "Batch Start Time";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(44, 287);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(83, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "Batch End Time";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtBatchName
            // 
            this.txtBatchName.Location = new System.Drawing.Point(22, 171);
            this.txtBatchName.Name = "txtBatchName";
            this.txtBatchName.Size = new System.Drawing.Size(126, 20);
            this.txtBatchName.TabIndex = 11;
            this.txtBatchName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtEquipName
            // 
            this.txtEquipName.Location = new System.Drawing.Point(22, 216);
            this.txtEquipName.Name = "txtEquipName";
            this.txtEquipName.Size = new System.Drawing.Size(126, 20);
            this.txtEquipName.TabIndex = 12;
            this.txtEquipName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtBatchID
            // 
            this.txtBatchID.Location = new System.Drawing.Point(22, 122);
            this.txtBatchID.Name = "txtBatchID";
            this.txtBatchID.Size = new System.Drawing.Size(126, 20);
            this.txtBatchID.TabIndex = 13;
            this.txtBatchID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tutorialDataGrid1
            // 
            this.tutorialDataGrid1.Location = new System.Drawing.Point(191, 12);
            this.tutorialDataGrid1.Name = "tutorialDataGrid1";
            this.tutorialDataGrid1.Size = new System.Drawing.Size(637, 531);
            this.tutorialDataGrid1.sqldgBatchEndTime = null;
            this.tutorialDataGrid1.sqldgBatchID = ((short)(1));
            this.tutorialDataGrid1.sqldgBatchName = "Batch1";
            this.tutorialDataGrid1.sqldgBatchStartTime = null;
            this.tutorialDataGrid1.sqldgDatabase = "";
            this.tutorialDataGrid1.sqldgEditMode = false;
            this.tutorialDataGrid1.sqldgEquipName = "Equip1";
            this.tutorialDataGrid1.sqldgGetData = false;
            this.tutorialDataGrid1.sqldgPassword = "";
            this.tutorialDataGrid1.sqldgServer = "";
            this.tutorialDataGrid1.sqldgTable = "Batches";
            this.tutorialDataGrid1.sqldgUser = "";
            this.tutorialDataGrid1.TabIndex = 14;
            this.tutorialDataGrid1.BatchIDChangedEvent += new TutorialDataGrid.TutorialDataGrid.BatchIDChangedEventHandler(this.tutorialDataGrid1_BatchIDChangedEvent);
            this.tutorialDataGrid1.BatchNameChangedEvent += new TutorialDataGrid.TutorialDataGrid.BatchNameChangedEventHandler(this.tutorialDataGrid1_BatchNameChangedEvent);
            this.tutorialDataGrid1.EquipNameChangedEvent += new TutorialDataGrid.TutorialDataGrid.EquipNameChangedEventHandler(this.tutorialDataGrid1_EquipNameChangedEvent);
            this.tutorialDataGrid1.BatchStartTimeChangedEvent += new TutorialDataGrid.TutorialDataGrid.BatchStartTimeChangedEventHandler(this.tutorialDataGrid1_BatchStartTimeChangedEvent);
            this.tutorialDataGrid1.BatchEndTimeChangedEvent += new TutorialDataGrid.TutorialDataGrid.BatchEndTimeChangedEventHandler(this.tutorialDataGrid1_BatchEndTimeChangedEvent);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(852, 557);
            this.Controls.Add(this.tutorialDataGrid1);
            this.Controls.Add(this.txtBatchID);
            this.Controls.Add(this.txtEquipName);
            this.Controls.Add(this.txtBatchName);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dtEnd);
            this.Controls.Add(this.dtStart);
            this.Controls.Add(this.btnEdit);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnEdit;
        private System.Windows.Forms.DateTimePicker dtStart;
        private System.Windows.Forms.DateTimePicker dtEnd;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtBatchName;
        private System.Windows.Forms.TextBox txtEquipName;
        private System.Windows.Forms.TextBox txtBatchID;
        private TutorialDataGrid.TutorialDataGrid tutorialDataGrid1;
    }
}

