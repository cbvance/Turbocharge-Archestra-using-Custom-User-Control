﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace testTutorialDataGrid
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        String sStartTime = "";
        String sEndTime = "";

        private void Form1_Load(object sender, EventArgs e)
        {
            tutorialDataGrid1.sqldgServer = "Charles-PC";
            tutorialDataGrid1.sqldgDatabase = "Tutorial";
            tutorialDataGrid1.sqldgUser = "wwUser";
            tutorialDataGrid1.sqldgPassword = "wwUser";
            tutorialDataGrid1.sqldgTable = "Batches";
            tutorialDataGrid1.sqldgGetData = true;

            tutorialDataGrid1.sqldgBatchName = "Batch1";
            tutorialDataGrid1.sqldgEquipName = "Equip1";
            tutorialDataGrid1.sqldgBatchStartTime = sStartTime;
            tutorialDataGrid1.sqldgBatchEndTime = dtEnd.Value.ToString();
            txtBatchID.Enabled = false;

        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            tutorialDataGrid1.sqldgEditMode = true;
            tutorialDataGrid1.sqldgBatchName = txtBatchName.Text;
            tutorialDataGrid1.sqldgEquipName = txtEquipName.Text;
            tutorialDataGrid1.sqldgBatchStartTime = dtStart.Value.ToString();
            tutorialDataGrid1.sqldgBatchEndTime = dtEnd.Value.ToString();
        }

        private void tutorialDataGrid1_BatchIDChangedEvent(object sender, TutorialDataGrid.SQLGridIntEventArgs e)
        {
            txtBatchID.Enabled = false;
            txtBatchID.Text = tutorialDataGrid1.sqldgBatchID.ToString().Trim();

        }

        private void tutorialDataGrid1_BatchNameChangedEvent(object sender, TutorialDataGrid.SQLGridStringsEventArgs e)
        {

            txtBatchName.Text = tutorialDataGrid1.sqldgBatchName;

        }

        private void tutorialDataGrid1_EquipNameChangedEvent(object sender, TutorialDataGrid.SQLGridStringsEventArgs e)
        {
            txtEquipName.Text = tutorialDataGrid1.sqldgEquipName;
        }

        private void tutorialDataGrid1_BatchStartTimeChangedEvent(object sender, TutorialDataGrid.SQLGridStringsEventArgs e)
        {
            dtStart.Value = DateTime.Parse(tutorialDataGrid1.sqldgBatchStartTime);
        }

        private void tutorialDataGrid1_BatchEndTimeChangedEvent(object sender, TutorialDataGrid.SQLGridStringsEventArgs e)
        {
            dtEnd.Value = DateTime.Parse(tutorialDataGrid1.sqldgBatchEndTime);
        }


    }
}
