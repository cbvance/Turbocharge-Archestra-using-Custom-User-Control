﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SQLGridControl
{
    public partial class SQLGrid : UserControl
    {
        


        public SQLGrid()
        {
            InitializeComponent();

        }

        DataTable _DataSource = new DataTable();

        //DataSource provides data table for data view grid 
        [Browsable(true)]
        [Description("Data View Grid for SQL"), Category("Data")]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]

        public DataTable DataSource
        {
            get { return _DataSource; }
            set
            {
                _DataSource = value;


                try
                {                   
                    dataGridView1.DataSource = _DataSource;
                }
                catch { }
            }
        }

    }
}
