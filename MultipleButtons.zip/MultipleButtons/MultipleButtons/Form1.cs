﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MultipleButtons
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();


            btn1.Click += new EventHandler(btn_Click);
            btn2.Click += new EventHandler(btn_Click);
            btn3.Click += new EventHandler(btn_Click);

            
        }
        public void btn_Click(object sender, EventArgs e)
        {

            switch ((sender as Button).Name)
            {
                case "btn1":
                    MessageBox.Show((sender as Button).Text);
                    break;
                case "btn2":
                    MessageBox.Show((sender as Button).Text);
                    break;
                case "btn3":
                    MessageBox.Show((sender as Button).Text);
                    break;
                default:
                    break;
            }
        }


    }
}
